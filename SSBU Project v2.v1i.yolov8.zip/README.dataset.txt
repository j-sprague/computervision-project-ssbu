# SSBU Project v2 > 2023-12-04 9:35pm
https://universe.roboflow.com/dtsc3000-uggrf/ssbu-project-v2

Provided by a Roboflow user
License: CC BY 4.0

