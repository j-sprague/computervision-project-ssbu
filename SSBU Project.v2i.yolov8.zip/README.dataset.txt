# SSBU Project > 2023-11-15 3:38pm
https://universe.roboflow.com/dtsc3000-uggrf/ssbu-project

Provided by a Roboflow user
License: CC BY 4.0

